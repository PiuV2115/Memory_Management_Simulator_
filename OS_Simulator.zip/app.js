/* ═══════════════════════════════════════════════════════════════
   app.js  —  OS Process Scheduler  |  Main application logic

   Sections:
     1.  Colour Palette
     2.  Algorithm Metadata (labels + explanations)
     3.  App State
     4.  ── SCHEDULING ENGINE ──
         4a. Helper: norm()       normalise process inputs
         4b. Helper: compress()   merge adjacent same-PID blocks
         4c. FCFS
         4d. SJF  (non-preemptive)
         4e. Priority  (non-preemptive)
         4f. SRTF  (preemptive SJF)
         4g. Round Robin
         4h. runAlgo()  dispatcher + metrics builder
     5.  ── UI RENDERERS ──
         5a. renderStrip()    algorithm pill bar
         5b. setAlgo()        switch algorithm + update UI
         5c. renderExplain()  description box
         5d. renderProcs()    process input table
         5e. addProc()        add a blank row
         5f. del()            remove a row
         5g. upd()            update a field value
     6.  ── SIMULATION RUNNER ──
         6a. runSim()
     7.  ── RESULT RENDERER ──
         7a. renderResult()
     8.  ── FIREBASE GLUE ──
         8a. saveResult()
         8b. loadHistory()
         8c. deleteHistory()
         8d. loadHistoryItem()
         8e. renderHistory()
     9.  Toast notifications
    10.  Firebase status poller
    11.  Init (called on page load)
═══════════════════════════════════════════════════════════════ */


/* ─────────────────────────────────────────────────────────────
   1. COLOUR PALETTE
      10 colours cycled across processes.
      pcolor(pid) maps a PID to a stable colour.
───────────────────────────────────────────────────────────── */
const PAL = [
  '#4338ca', /* indigo  */
  '#0f766e', /* teal    */
  '#b45309', /* amber   */
  '#9333ea', /* violet  */
  '#0369a1', /* sky     */
  '#be185d', /* pink    */
  '#15803d', /* green   */
  '#c2410c', /* orange  */
  '#7c3aed', /* purple  */
  '#0891b2'  /* cyan    */
];

/**
 * Returns a colour for a given PID based on its position
 * in the current process list. Stable as long as list order
 * doesn't change.
 */
function pcolor(pid) {
  const ids = [...new Set(procs.map(x => x.pid))];
  return PAL[ids.indexOf(pid) % PAL.length] || PAL[0];
}


/* ─────────────────────────────────────────────────────────────
   2. ALGORITHM METADATA
      Each key maps to:
        label  — short abbreviation shown in the pill strip
        full   — full readable name
        explain— HTML description shown in the explain box
───────────────────────────────────────────────────────────── */
const ALGO_META = {
  fcfs: {
    label: 'FCFS',
    full:  'First Come First Served',
    explain: '<strong>Non-preemptive.</strong> Processes execute in the order they arrive. '
           + 'Simple and fair, but short jobs can get stuck behind long ones '
           + '(the <em>convoy effect</em>). Best when burst times are similar.'
  },
  sjf: {
    label: 'SJF',
    full:  'Shortest Job First',
    explain: '<strong>Non-preemptive.</strong> The process with the shortest burst time '
           + 'runs next. Minimises average waiting time but requires knowing burst times '
           + 'in advance. Long processes can starve if short ones keep arriving.'
  },
  srtf: {
    label: 'SRTF',
    full:  'Shortest Remaining Time First',
    explain: '<strong>Preemptive SJF.</strong> A newly arrived process can preempt the '
           + 'current one if it has less remaining time. Achieves the optimal average '
           + 'wait time but generates many context switches.'
  },
  priority: {
    label: 'Priority',
    full:  'Priority Scheduling',
    explain: '<strong>Non-preemptive.</strong> Lower priority number = higher priority. '
           + 'Processes with higher priority always run first. '
           + 'Low-priority processes risk <em>starvation</em> if high-priority '
           + 'processes keep arriving.'
  },
  rr: {
    label: 'Round Robin',
    full:  'Round Robin',
    explain: '<strong>Preemptive.</strong> Each process gets a fixed time quantum in '
           + 'rotation. Very fair and responsive. Quantum size matters: too small '
           + 'causes excessive context switches; too large degrades to FCFS. '
           + 'Standard for time-sharing systems.'
  }
};


/* ─────────────────────────────────────────────────────────────
   3. APP STATE
      Mutable variables that represent the current state
      of the application.
───────────────────────────────────────────────────────────── */

/* Currently selected algorithm key */
let algo = 'fcfs';

/* Array of process objects.
   Each: { id, pid, at (arrival), bt (burst), pr (priority) } */
let procs = [
  { id: 1, pid: 'P1', at: 0, bt: 6, pr: 3 },
  { id: 2, pid: 'P2', at: 2, bt: 4, pr: 1 },
  { id: 3, pid: 'P3', at: 4, bt: 2, pr: 2 },
  { id: 4, pid: 'P4', at: 5, bt: 5, pr: 4 }
];

/* Auto-incrementing ID for new processes */
let nextId = 5;

/* Array of history items loaded from Firebase */
let history = [];

/* The last computed simulation result (used for saving) */
let currentResult = null;


/* ═══════════════════════════════════════════════════════════════
   4. SCHEDULING ENGINE
   Pure functions — no DOM access, no side effects.
   All take normalised process arrays and return Gantt arrays:
     [ [pid, startTime, endTime], ... ]
═══════════════════════════════════════════════════════════════ */

/* ── 4a. norm() ─────────────────────────────────────────────
   Normalises raw input values:
   - Converts strings to numbers
   - Clamps burst time to at least 1
   - Defaults missing priority to 999 (lowest)
─────────────────────────────────────────────────────────── */
function norm(ps) {
  return ps.map(p => ({
    pid: p.pid,
    at:  +p.at || 0,                            /* arrival time  */
    bt:  Math.max(1, +p.bt || 1),               /* burst time    */
    pr:  (p.pr !== '' && p.pr != null) ? +p.pr : 999  /* priority */
  }));
}

/* ── 4b. compress() ─────────────────────────────────────────
   Merges consecutive Gantt entries for the same PID.
   Example: [ [P1,0,1],[P1,1,2],[P2,2,4] ]
         →  [ [P1,0,2],[P2,2,4] ]
   Important for SRTF which generates 1-unit raw entries.
─────────────────────────────────────────────────────────── */
function compress(g) {
  if (!g.length) return [];
  const o = [[...g[0]]];
  for (let i = 1; i < g.length; i++) {
    const [pid, s, e] = g[i];
    const last = o[o.length - 1];
    /* If same PID and time is contiguous, just extend the end */
    if (pid === last[0] && s === last[2]) {
      last[2] = e;
    } else {
      o.push([...g[i]]);
    }
  }
  return o;
}

/* ── 4c. FCFS — First Come First Served ────────────────────
   Sort by arrival time, then execute each in order.
   If CPU is idle between processes, advance time to next arrival.
─────────────────────────────────────────────────────────── */
function fcfsFn(ps) {
  let t = 0;   /* current time */
  const g = [];
  const sorted = [...ps].sort((a, b) => a.at - b.at || a.pid.localeCompare(b.pid));

  for (const p of sorted) {
    if (t < p.at) t = p.at;          /* CPU idle — jump to arrival */
    g.push([p.pid, t, t + p.bt]);
    t += p.bt;
  }
  return g;
}

/* ── 4d. SJF — Shortest Job First (Non-preemptive) ─────────
   At each scheduling point, pick the ready process
   with the smallest burst time.
─────────────────────────────────────────────────────────── */
function sjfFn(ps) {
  const arr = [...ps].sort((a, b) => a.at - b.at);
  let t = 0, i = 0, done = 0;
  const ready = [], g = [];

  while (done < arr.length) {
    /* Add all processes that have arrived by now to ready queue */
    while (i < arr.length && arr[i].at <= t) ready.push(arr[i++]);

    if (!ready.length) {
      /* No process ready — jump time forward to next arrival */
      t = arr[i].at;
      continue;
    }

    /* Pick the shortest burst time from ready queue */
    ready.sort((a, b) => a.bt - b.bt || a.at - b.at);
    const p = ready.shift();
    g.push([p.pid, t, t + p.bt]);
    t += p.bt;
    done++;
  }
  return g;
}

/* ── 4e. Priority (Non-preemptive) ─────────────────────────
   Same structure as SJF but sorts ready queue by priority
   (lower number = higher priority).
─────────────────────────────────────────────────────────── */
function priorityFn(ps) {
  const arr = [...ps].sort((a, b) => a.at - b.at);
  let t = 0, i = 0, done = 0;
  const ready = [], g = [];

  while (done < arr.length) {
    while (i < arr.length && arr[i].at <= t) ready.push(arr[i++]);

    if (!ready.length) {
      t = arr[i].at;
      continue;
    }

    /* Pick highest priority (lowest pr number) */
    ready.sort((a, b) => a.pr - b.pr || a.at - b.at);
    const p = ready.shift();
    g.push([p.pid, t, t + p.bt]);
    t += p.bt;
    done++;
  }
  return g;
}

/* ── 4f. SRTF — Shortest Remaining Time First ───────────────
   Preemptive: runs 1 time unit at a time, always picking
   the process with the least remaining burst time.
   Uses compress() to merge the raw 1-unit entries.
─────────────────────────────────────────────────────────── */
function srtfFn(ps) {
  const arr = [...ps].sort((a, b) => a.at - b.at);

  /* Track remaining burst for each PID */
  const rem = {};
  arr.forEach(p => rem[p.pid] = p.bt);

  /* Start time = earliest arrival */
  let t = Math.min(...arr.map(p => p.at));
  let i = 0, done = 0;
  const ready = [], raw = [];  /* raw = 1-unit Gantt entries */

  while (done < arr.length) {
    /* Admit newly arrived processes */
    while (i < arr.length && arr[i].at <= t) ready.push(arr[i++]);

    const alive = ready.filter(p => rem[p.pid] > 0);
    if (!alive.length) {
      if (i < arr.length) { t = arr[i].at; continue; }
      break;
    }

    /* Pick process with shortest remaining time */
    alive.sort((a, b) => rem[a.pid] - rem[b.pid] || a.at - b.at);
    const p = alive[0];

    /* Run it for exactly 1 unit */
    raw.push([p.pid, t, t + 1]);
    rem[p.pid]--;
    t++;

    if (rem[p.pid] === 0) done++;
  }

  return compress(raw);
}

/* ── 4g. Round Robin ────────────────────────────────────────
   Each process runs for at most `q` time units, then goes
   to the back of the queue. New arrivals join after the
   current quantum completes.
─────────────────────────────────────────────────────────── */
function rrFn(ps, q) {
  const arr = [...ps].sort((a, b) => a.at - b.at);
  const rem = {};
  arr.forEach(p => rem[p.pid] = p.bt);

  let t = 0, i = 0, done = 0;
  const queue = [], g = [];

  /* Seed queue with processes that arrive at t=0 */
  while (i < arr.length && arr[i].at <= t) queue.push(arr[i++]);

  while (done < arr.length) {
    if (!queue.length) {
      /* Gap in execution — advance to next arrival */
      t = arr[i].at;
      while (i < arr.length && arr[i].at <= t) queue.push(arr[i++]);
      continue;
    }

    const p    = queue.shift();
    const run  = Math.min(q, rem[p.pid]);  /* can't run more than remaining */

    g.push([p.pid, t, t + run]);
    rem[p.pid] -= run;
    t += run;

    /* Admit processes that arrived during this quantum */
    while (i < arr.length && arr[i].at <= t) queue.push(arr[i++]);

    if (rem[p.pid] > 0) {
      queue.push(p);   /* process not done — re-queue */
    } else {
      done++;
    }
  }

  return compress(g);
}

/* ── 4h. runAlgo() — dispatcher + metrics builder ───────────
   1. Normalises process input
   2. Calls the right algorithm function
   3. Builds per-process metrics from the Gantt output
   4. Computes summary statistics
   Returns a result object used by renderResult() and saveResult()
─────────────────────────────────────────────────────────── */
function runAlgo(a, ps, q) {
  const p = norm(ps);

  /* Dispatch to the correct algorithm */
  let g;
  if      (a === 'fcfs')     g = fcfsFn(p);
  else if (a === 'sjf')      g = sjfFn(p);
  else if (a === 'srtf')     g = srtfFn(p);
  else if (a === 'priority') g = priorityFn(p);
  else                       g = rrFn(p, Math.max(1, q));

  /* Build completion time (ct) and first-start time (fs) maps */
  const ct = {}, fs = {};
  for (const [pid, s, e] of g) {
    if (!(pid in fs)) fs[pid] = s;   /* record first time process got CPU */
    ct[pid] = e;                      /* keep overwriting — last end = completion */
  }

  /* Per-process metrics */
  let totalWait = 0, totalTat = 0;
  const per = p.map(x => {
    const tat = ct[x.pid] - x.at;    /* turnaround = completion - arrival    */
    const wt  = tat - x.bt;          /* wait       = turnaround - burst      */
    const rt  = fs[x.pid] - x.at;    /* response   = first CPU   - arrival   */
    totalWait += wt;
    totalTat  += tat;
    return { pid: x.pid, ct: ct[x.pid], tat, wt, rt, bt: x.bt };
  });

  /* Summary statistics */
  const n    = p.length;
  const et   = Math.max(...Object.values(ct));
  const st   = Math.min(...p.map(x => x.at));
  const busy = g.reduce((acc, [, s, e]) => acc + e - s, 0);
  const span = Math.max(1, et - st);   /* total time span (avoid divide by 0) */

  return {
    /* Convert Gantt array-of-tuples to array-of-objects for easier use */
    gantt: g.map(([pid, start, end]) => ({ pid, start, end })),
    per,
    summary: {
      avg_wt:      +(totalWait / n).toFixed(2),
      avg_tat:     +(totalTat  / n).toFixed(2),
      cpu_util:    +((busy / span) * 100).toFixed(1),
      throughput:  +(n / span).toFixed(3)
    }
  };
}


/* ═══════════════════════════════════════════════════════════════
   5. UI RENDERERS
   Functions that read state and write to the DOM.
═══════════════════════════════════════════════════════════════ */

/* ── 5a. renderStrip() ──────────────────────────────────────
   Builds the algorithm selection pill bar at the top.
   Marks the currently active algorithm with class 'on'.
─────────────────────────────────────────────────────────── */
function renderStrip() {
  document.getElementById('algoStrip').innerHTML =
    Object.entries(ALGO_META).map(([k, v]) =>
      `<button class="algo-pill${algo === k ? ' on' : ''}" onclick="setAlgo('${k}')">
        ${v.label}
       </button>`
    ).join('');
}

/* ── 5b. setAlgo() ──────────────────────────────────────────
   Called when user clicks an algorithm pill.
   Updates state, re-renders the strip, explanation,
   and shows/hides the quantum input row.
─────────────────────────────────────────────────────────── */
function setAlgo(k) {
  algo = k;
  renderStrip();
  renderExplain();
  /* Only Round Robin needs the quantum input */
  document.getElementById('quantumRow').style.display = (k === 'rr') ? 'flex' : 'none';
}

/* ── 5c. renderExplain() ────────────────────────────────────
   Fills the explain box with the selected algorithm's
   description HTML.
─────────────────────────────────────────────────────────── */
function renderExplain() {
  const m = ALGO_META[algo];
  document.getElementById('explainBox').innerHTML =
    `<p><strong>${m.full}.</strong> ${m.explain}</p>`;
}

/* ── 5d. renderProcs() ──────────────────────────────────────
   Rebuilds the entire process table from the procs array.
   Each row gets inline onchange handlers that call upd().
─────────────────────────────────────────────────────────── */
function renderProcs() {
  document.getElementById('procBody').innerHTML =
    procs.map(p => `
      <tr>
        <td><input class="pid-cell" value="${p.pid}"
              onchange="upd(${p.id}, 'pid', this.value)"></td>
        <td><input type="number" min="0" value="${p.at}"
              onchange="upd(${p.id}, 'at', this.value)"></td>
        <td><input type="number" min="1" value="${p.bt}"
              onchange="upd(${p.id}, 'bt', this.value)"></td>
        <td><input type="number" value="${p.pr}" placeholder="—"
              onchange="upd(${p.id}, 'pr', this.value)"></td>
        <td><button class="del-btn" onclick="del(${p.id})">✕</button></td>
      </tr>
    `).join('');

  /* Update the process count label */
  document.getElementById('procCount').textContent =
    procs.length + ' process' + (procs.length !== 1 ? 'es' : '');
}

/* ── 5e. addProc() ──────────────────────────────────────────
   Appends a new blank process to the list and re-renders.
─────────────────────────────────────────────────────────── */
function addProc() {
  const id = nextId++;
  procs.push({ id, pid: 'P' + id, at: 0, bt: 1, pr: '' });
  renderProcs();
}

/* ── 5f. del() ──────────────────────────────────────────────
   Removes a process by its internal id.
   Prevents removing the last process.
─────────────────────────────────────────────────────────── */
function del(id) {
  if (procs.length <= 1) {
    toast('Need at least 1 process', 'err');
    return;
  }
  procs = procs.filter(x => x.id !== id);
  renderProcs();
}

/* ── 5g. upd() ──────────────────────────────────────────────
   Updates a single field on a single process in state.
   Called by inline onchange handlers in the table.
─────────────────────────────────────────────────────────── */
function upd(id, field, value) {
  procs = procs.map(x => x.id === id ? { ...x, [field]: value } : x);
}


/* ═══════════════════════════════════════════════════════════════
   6. SIMULATION RUNNER
═══════════════════════════════════════════════════════════════ */

/* ── 6a. runSim() ───────────────────────────────────────────
   Triggered by the Simulate button.
   Shows loading state, runs the algorithm after a short
   delay (so the browser can paint the loading state first),
   then renders the result.
─────────────────────────────────────────────────────────── */
function runSim() {
  if (!procs.length) return;

  const btn = document.getElementById('runBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spin">⟳</span> Running…';

  /* Small timeout so the browser repaints before heavy work */
  setTimeout(() => {
    try {
      const q = +document.getElementById('quantum').value || 2;
      currentResult = runAlgo(algo, procs, q);
      renderResult(currentResult);
    } catch (e) {
      toast('Simulation error: ' + e.message, 'err');
    }

    /* Reset button */
    btn.disabled = false;
    btn.innerHTML =
      '<svg width="10" height="10" viewBox="0 0 10 10">' +
      '<polygon points="1,0 10,5 1,10" fill="currentColor"/></svg> Simulate';
  }, 250);
}


/* ═══════════════════════════════════════════════════════════════
   7. RESULT RENDERER
═══════════════════════════════════════════════════════════════ */

/* ── 7a. renderResult(res) ──────────────────────────────────
   Takes a result object from runAlgo() and builds the
   entire right-column HTML:
     - 4 summary stat boxes
     - Gantt chart track with coloured blocks
     - Tick marks + legend
     - Per-process metrics table with inline bar charts
     - 4 insight boxes
─────────────────────────────────────────────────────────── */
function renderResult(res) {
  const pids    = [...new Set(res.gantt.map(g => g.pid))];
  const total   = Math.max(...res.gantt.map(g => g.end), 1);  /* total time span */
  const ticks   = [...new Set([0, ...res.gantt.map(g => g.end)])].sort((a, b) => a - b);
  const maxWt   = Math.max(...res.per.map(p => p.wt), 1);
  const maxTat  = Math.max(...res.per.map(p => p.tat), 1);
  const s       = res.summary;

  /* ── Gantt blocks ── */
  const blocks = res.gantt.map((g, i) => {
    const w = ((g.end - g.start) / total * 100);  /* percentage width */
    const c = pcolor(g.pid);
    return `
      <div class="gblock" style="width:${w}%;background:${c}"
           title="${g.pid}: t${g.start}→t${g.end} (${g.end - g.start}u)">
        ${w > 5
          ? `<span class="gb-pid">${g.pid}</span>
             <span class="gb-t">${g.start}-${g.end}</span>`
          : ''  /* hide labels in very narrow blocks */
        }
        <span class="gblock-sep"></span>
      </div>`;
  }).join('');

  /* ── Tick marks on time axis ── */
  const ticksHtml = ticks.map(t =>
    `<span class="tick" style="left:${(t / total * 100)}%">${t}</span>`
  ).join('');

  /* ── Colour legend ── */
  const legHtml = pids.map(pid =>
    `<div class="leg-item">
       <div class="leg-dot" style="background:${pcolor(pid)}"></div>
       <span>${pid}</span>
     </div>`
  ).join('');

  /* ── Per-process metrics rows ── */
  const metricsRows = res.per.map(p => {
    const c      = pcolor(p.pid);
    const tatPct = (p.tat / maxTat * 100).toFixed(1);
    const wtPct  = (p.wt  / maxWt  * 100).toFixed(1);

    /* Colour wait time: green if 0, red if in top 30%, grey otherwise */
    const wtColor = p.wt === 0
      ? 'var(--green)'
      : p.wt > maxWt * 0.7
        ? 'var(--red)'
        : 'var(--text2)';

    return `
      <tr>
        <td style="color:${c};font-weight:700">${p.pid}</td>
        <td>${p.bt}</td>
        <td>${p.ct}</td>
        <td>
          <div class="bar-wrap">
            <div class="bar-bg">
              <div class="bar-fill" style="width:${tatPct}%;background:${c}88"></div>
            </div>
            <span class="bar-num">${p.tat}</span>
          </div>
        </td>
        <td>
          <div class="bar-wrap">
            <div class="bar-bg">
              <div class="bar-fill" style="width:${wtPct}%;background:${c}"></div>
            </div>
            <span class="bar-num" style="color:${wtColor}">${p.wt}</span>
          </div>
        </td>
        <td>${p.rt}</td>
      </tr>`;
  }).join('');

  /* ── Auto-generated insights ── */
  const bestP    = res.per.reduce((a, b) => a.wt < b.wt ? a : b);    /* least wait  */
  const worstP   = res.per.reduce((a, b) => a.wt > b.wt ? a : b);    /* most wait   */
  const switches = res.gantt.length - 1;                               /* context switches = transitions between blocks */
  const isPreemptive = (algo === 'srtf' || algo === 'rr');

  /* ── Inject full result HTML into the right pane ── */
  document.getElementById('resultPane').innerHTML = `
  <div class="card animate-in">
    <div class="card-head">
      <span class="card-title">Simulation Results</span>
      <div style="display:flex;gap:8px;align-items:center">
        <span class="algo-tag">${ALGO_META[algo].full}</span>
        <button class="btn btn-save" id="saveBtn" onclick="saveResult()">
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
            <path d="M2 2h7l2 2v7a1 1 0 01-1 1H2a1 1 0 01-1-1V3a1 1 0 011-1z"
                  stroke="currentColor" stroke-width="1.2"/>
            <rect x="3.5" y="7.5" width="6" height="4" rx=".5"
                  stroke="currentColor" stroke-width="1.2"/>
            <rect x="4.5" y="2" width="4" height="3" rx=".5"
                  stroke="currentColor" stroke-width="1.2"/>
          </svg>
          Save to Firebase
        </button>
      </div>
    </div>
    <div class="card-body">

      <!-- 4 summary stat boxes -->
      <div class="stats-grid">
        <div class="stat-box">
          <div class="stat-label">Avg wait time</div>
          <div class="stat-val" style="color:var(--purple)">
            ${s.avg_wt}<span class="stat-unit">u</span>
          </div>
        </div>
        <div class="stat-box">
          <div class="stat-label">Avg turnaround</div>
          <div class="stat-val" style="color:var(--teal)">
            ${s.avg_tat}<span class="stat-unit">u</span>
          </div>
        </div>
        <div class="stat-box">
          <div class="stat-label">CPU utilization</div>
          <div class="stat-val" style="color:var(--green)">
            ${s.cpu_util}<span class="stat-unit">%</span>
          </div>
        </div>
        <div class="stat-box">
          <div class="stat-label">Throughput</div>
          <div class="stat-val" style="color:var(--amber)">
            ${s.throughput}<span class="stat-unit">p/u</span>
          </div>
        </div>
      </div>

      <!-- Gantt chart -->
      <div style="margin-bottom:20px">
        <div class="sec-lbl">Gantt chart — execution timeline</div>
        <div class="gantt-track">${blocks}</div>
        <div class="ticks-row">${ticksHtml}</div>
        <div class="legend-row">${legHtml}</div>
      </div>

      <!-- Per-process metrics table -->
      <div style="margin-bottom:4px">
        <div class="sec-lbl">Per-process metrics</div>
        <table class="mtbl">
          <thead><tr>
            <th style="width:14%;text-align:left">Process</th>
            <th style="width:12%">Burst</th>
            <th style="width:14%">Completion</th>
            <th style="width:22%">Turnaround</th>
            <th style="width:22%">Wait time</th>
            <th style="width:16%">Response</th>
          </tr></thead>
          <tbody>${metricsRows}</tbody>
        </table>
      </div>

      <!-- Insight boxes -->
      <div class="insights-grid">
        <div class="ins-box">
          <div class="ins-label">Least wait</div>
          <div class="ins-val" style="color:${pcolor(bestP.pid)};font-family:var(--mono)">
            ${bestP.pid}
          </div>
          <div class="ins-sub">${bestP.wt}u waited</div>
        </div>
        <div class="ins-box">
          <div class="ins-label">Most wait</div>
          <div class="ins-val" style="color:${pcolor(worstP.pid)};font-family:var(--mono)">
            ${worstP.pid}
          </div>
          <div class="ins-sub">${worstP.wt}u waited</div>
        </div>
        <div class="ins-box">
          <div class="ins-label">Context switches</div>
          <div class="ins-val">${switches}</div>
          <div class="ins-sub">${isPreemptive ? 'preemptive' : 'non-preemptive'}</div>
        </div>
        <div class="ins-box">
          <div class="ins-label">Total span</div>
          <div class="ins-val">
            ${total}<span style="font-size:12px;color:var(--text3);font-family:var(--mono)"> u</span>
          </div>
          <div class="ins-sub">${res.gantt.length} burst${res.gantt.length !== 1 ? 's' : ''}</div>
        </div>
      </div>

    </div>
  </div>`;
}


/* ═══════════════════════════════════════════════════════════════
   8. FIREBASE GLUE
   These functions call the globals exposed by firebase.js.
   They are safely guarded — if Firebase isn't configured
   they show a helpful toast and do nothing.
═══════════════════════════════════════════════════════════════ */

/* ── 8a. saveResult() ───────────────────────────────────────
   Packages the current simulation result and sends it to
   Firestore via window.__fbSave. Then reloads history.
─────────────────────────────────────────────────────────── */
async function saveResult() {
  if (!currentResult) return;

  const btn = document.getElementById('saveBtn');
  if (!btn) return;

  if (!window.__fbSave) {
    toast('Firebase not configured — paste your config in firebase.js', 'err');
    return;
  }

  btn.disabled = true;
  btn.innerHTML = '<span class="spin">⟳</span> Saving…';

  try {
    /* Build the document to store */
    const data = {
      algorithm:    algo,
      algoFull:     ALGO_META[algo].full,
      processCount: procs.length,
      avg_wt:       currentResult.summary.avg_wt,
      avg_tat:      currentResult.summary.avg_tat,
      cpu_util:     currentResult.summary.cpu_util,
      throughput:   currentResult.summary.throughput,
      /* Store full process list so we can reload them later */
      processes:    procs.map(p => ({
        pid: p.pid,
        at:  +p.at,
        bt:  +p.bt,
        pr:  p.pr || null
      })),
      /* Store the full result so we can re-render it without recalculating */
      result: currentResult
    };

    await window.__fbSave(data);
    toast('Saved to Firebase!', 'ok');
    await loadHistory();             /* refresh the history panel */

  } catch (e) {
    toast('Save failed: ' + e.message, 'err');
  }

  /* Restore button */
  if (document.getElementById('saveBtn')) {
    document.getElementById('saveBtn').disabled = false;
    document.getElementById('saveBtn').innerHTML =
      '<svg width="13" height="13" viewBox="0 0 13 13" fill="none">' +
      '<path d="M2 2h7l2 2v7a1 1 0 01-1 1H2a1 1 0 01-1-1V3a1 1 0 011-1z" stroke="currentColor" stroke-width="1.2"/>' +
      '<rect x="3.5" y="7.5" width="6" height="4" rx=".5" stroke="currentColor" stroke-width="1.2"/>' +
      '<rect x="4.5" y="2" width="4" height="3" rx=".5" stroke="currentColor" stroke-width="1.2"/>' +
      '</svg> Save to Firebase';
  }
}

/* ── 8b. loadHistory() ──────────────────────────────────────
   Fetches all saved simulations from Firestore and
   stores them in the history array, then re-renders.
─────────────────────────────────────────────────────────── */
async function loadHistory() {
  if (!window.__fbLoad) return;
  try {
    history = await window.__fbLoad();
    renderHistory();
  } catch (e) {
    console.warn('Load history failed', e);
  }
}

/* ── 8c. deleteHistory() ────────────────────────────────────
   Deletes a document from Firestore by ID.
   e.stopPropagation() prevents triggering the loadHistoryItem
   click on the parent row.
─────────────────────────────────────────────────────────── */
async function deleteHistory(id, e) {
  e.stopPropagation();
  if (!window.__fbDelete) return;
  try {
    await window.__fbDelete(id);
    toast('Deleted', 'info');
    await loadHistory();   /* refresh after deletion */
  } catch (e) {
    toast('Delete failed: ' + e.message, 'err');
  }
}

/* ── 8d. loadHistoryItem() ──────────────────────────────────
   Restores a saved simulation: reloads the process list,
   switches algorithm, and re-renders the result.
─────────────────────────────────────────────────────────── */
function loadHistoryItem(item) {
  if (item.algorithm) setAlgo(item.algorithm);

  if (item.processes) {
    procs  = item.processes.map((p, i) => ({ ...p, id: i + 1 }));
    nextId = procs.length + 1;
    renderProcs();
  }

  if (item.result) {
    currentResult = item.result;
    renderResult(item.result);
  }

  toast('Loaded — ' + item.algoFull, 'info');
}

/* ── 8e. renderHistory() ────────────────────────────────────
   Renders the saved simulations list in the left panel.
   Each item is clickable (loads it) and has a ✕ delete button.
   JSON.stringify + attribute escaping lets us pass the full
   item object via onclick without a separate data store.
─────────────────────────────────────────────────────────── */
function renderHistory() {
  const hb = document.getElementById('histBody');
  const hc = document.getElementById('histCount');

  hc.textContent = history.length ? history.length + ' saved' : '';

  if (!history.length) {
    hb.innerHTML = `
      <div class="empty" style="padding:24px 10px">
        <div class="empty-icon">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M4 4h12v2H4zM4 8h12v2H4zM4 12h8v2H4z" fill="var(--text3)"/>
          </svg>
        </div>
        <h3>No saved runs</h3>
        <p>Run a simulation and click Save to store results in Firebase.</p>
      </div>`;
    return;
  }

  hb.innerHTML = history.map(item => `
    <div class="hist-item"
         onclick="loadHistoryItem(${JSON.stringify(item).replace(/"/g, '&quot;')})">
      <div style="flex:1;min-width:0">
        <div class="hist-algo">${item.algoFull || item.algorithm}</div>
        <div class="hist-meta">
          ${item.processCount} processes ·
          ${new Date(item.timestamp).toLocaleString()}
        </div>
      </div>
      <div class="hist-stats">
        <div>WT ${item.avg_wt}</div>
        <div>TAT ${item.avg_tat}</div>
      </div>
      <button class="hist-del"
              onclick="deleteHistory('${item.id}', event)"
              title="Delete">✕</button>
    </div>
  `).join('');
}


/* ═══════════════════════════════════════════════════════════════
   9. TOAST NOTIFICATIONS
   Creates a temporary notification div, appends it to
   #toastWrap, and removes it after 3.5 seconds.
   Types: 'ok' (green), 'err' (red), 'info' (blue)
═══════════════════════════════════════════════════════════════ */
function toast(msg, type = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icon = type === 'ok' ? '✓' : type === 'err' ? '✕' : 'ℹ';
  el.innerHTML = icon + ' ' + msg;
  document.getElementById('toastWrap').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}


/* ═══════════════════════════════════════════════════════════════
   10. FIREBASE STATUS POLLER
   firebase.js sets window.__fbReady = true|false asynchronously.
   We poll every 200ms until it's set (or 6 seconds pass).
   Updates the header badge colour and label accordingly.
═══════════════════════════════════════════════════════════════ */
function checkDbStatus() {
  let tries = 0;
  const poll = setInterval(() => {
    tries++;
    const dot = document.getElementById('dbDot');
    const lbl = document.getElementById('dbLabel');

    if (window.__fbReady === true) {
      clearInterval(poll);
      dot.classList.add('live');
      lbl.textContent = 'Firebase Live';
      loadHistory();    /* auto-load history once connected */

    } else if (window.__fbReady === false || tries > 30) {
      clearInterval(poll);
      dot.classList.add('err');
      lbl.textContent = 'Configure Firebase';
    }
    /* else: still undefined — keep polling */
  }, 200);
}


/* ═══════════════════════════════════════════════════════════════
   11. INIT — called immediately when the script loads
   Renders the initial UI state.
═══════════════════════════════════════════════════════════════ */
renderStrip();      /* draw algorithm pills          */
renderExplain();    /* show FCFS explanation          */
renderProcs();      /* show default process table     */
checkDbStatus();    /* start watching for Firebase    */
